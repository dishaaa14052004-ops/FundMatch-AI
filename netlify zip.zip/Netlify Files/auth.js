console.log("AUTH JS LOADED");

// 🔐 Firebase Config
const firebaseConfig = {
  apiKey: "AIzaSyCrAvxQdK-pSu5LxhyKFxwFXJyGrovLvYU",
  authDomain: "fundmatch-ai.firebaseapp.com",
  projectId: "fundmatch-ai",
  storageBucket: "fundmatch-ai.firebasestorage.app",
  messagingSenderId: "210747145526",
  appId: "1:210747145526:web:ab8920d962867c8b360797"
};

firebase.initializeApp(firebaseConfig);

// 📧 EmailJS init
(function(){
  emailjs.init("SO0IH-c_KnueDLYUC");
})();

// CAPTCHA
let generatedCaptcha;

function generateCaptcha(){
  generatedCaptcha = Math.floor(1000 + Math.random()*9000);
  document.getElementById("captchaBox").innerText = generatedCaptcha;
}

// ================= SIGNUP =================
async function signup(){

  let name = document.getElementById("name").value;
  let email = document.getElementById("email").value;
  let password = document.getElementById("password").value;
  let captchaInput = document.getElementById("captchaInput").value;

  if(captchaInput != generatedCaptcha){
    alert("Wrong Captcha");
    generateCaptcha();
    return;
  }

  try {
    console.log("STEP 1: Creating user");

    await firebase.auth().createUserWithEmailAndPassword(email, password);

    localStorage.setItem("userLoggedIn", true);

    console.log("STEP 2: Firebase success");

    // Save to Google Sheet (non-blocking)
    fetch("https://script.google.com/macros/s/AKfycbyHmThWxkcplC3aIXuxF9krb3trYItl-xeRfOA3CihU3IXWWpimJQ4AhrDExniyVQ_z/exec", {
      method: "POST",
      mode: "no-cors",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        type: "signup",
        name: name,
        email: email
      })
    });

    // ✅ EmailJS should NOT break signup
    try {
      await emailjs.send("service_zmnyjp5", "template_gr3szd3", {
        name: name,
        email: email
      });
      console.log("✅ Email sent");
    } catch (emailError) {
      console.warn("⚠️ Email failed but continuing:", emailError);
    }

    alert("Signup successful ✅");
    window.location.href = "getstarted.html";

  } catch (err) {
    console.error("❌ SIGNUP ERROR:", err);
    alert(err?.message || "Signup failed");
  }
}

// ================= LOGIN =================
function login(){

  let email = document.getElementById("email").value;
  let password = document.getElementById("password").value;

  firebase.auth().signInWithEmailAndPassword(email, password)
  .then(async () => {

    localStorage.setItem("userLoggedIn", true);

    // ✅ EmailJS should NOT block login
    try {
      await emailjs.send("service_zmnyjp5", "template_gr3szd3", {
        name: email,
        email: email
      });
    } catch (e) {
      console.warn("⚠️ Email failed but login continues", e);
    }

    window.location.href = "getstarted.html";

  })
  .catch((error) => {
    alert(error?.message || "Invalid login");
  });
}

// ================= GOOGLE LOGIN =================
const provider = new firebase.auth.GoogleAuthProvider();

async function googleLogin(){
  try {
    console.log("STEP 1: Google login start");

    const result = await firebase.auth().signInWithPopup(provider);

    localStorage.setItem("userLoggedIn", true);

    let name = result.user.displayName || "User";
    let email = result.user.email;

    console.log("STEP 2:", name, email);

    // Save to sheet (non-blocking)
    fetch("https://script.google.com/macros/s/AKfycbyHmThWxkcplC3aIXuxF9krb3trYItl-xeRfOA3CihU3IXWWpimJQ4AhrDExniyVQ_z/exec", {
      method: "POST",
      mode: "no-cors",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        type: "google",
        name: name,
        email: email
      })
    });

    // ✅ EmailJS wrapped safely
    try {
      await emailjs.send("service_zmnyjp5", "template_gr3szd3", {
        name: name,
        email: email
      });
      console.log("✅ Email sent");
    } catch (emailError) {
      console.warn("⚠️ Email failed but continuing:", emailError);
    }

    window.location.href = "getstarted.html";

  } catch (err) {
    console.error("❌ Google login error:", err);
    alert(err?.message || JSON.stringify(err) || "Google login failed");
  }
}